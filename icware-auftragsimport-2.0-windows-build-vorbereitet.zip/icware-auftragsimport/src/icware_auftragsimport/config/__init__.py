"""Validierte Einstellungen ohne Geheimnisse."""
