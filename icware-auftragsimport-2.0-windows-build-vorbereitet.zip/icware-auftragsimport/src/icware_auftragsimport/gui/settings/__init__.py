"""Einstellungen: Firmenprofile und Artikelkatalog."""
